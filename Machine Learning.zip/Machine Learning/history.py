# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Wed Jun 12 05:08:22 2019)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')
 12
7

## ---(Sat Jun 15 18:54:46 2019)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Wed Jul 17 08:54:36 2019)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Tue Sep 17 23:30:57 2019)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Wed Sep 18 07:03:54 2019)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')
87
90
print("Enter 'x' for exit.");
print("Enter marks obtained in 5 subjects: ");
mark1 = input();
if mark1 == 'x':
    exit();
else:
    mark1 = int(mark1);
    mark2 = int(input());
    mark3 = int(input());
    mark4 = int(input());
    mark5 = int(input());
    sum = mark1 + mark2 + mark3 + mark4 + mark5;
    average = sum/5;
    if(average>=91 and average<=100):
    	print("Your Grade is A+");
    elif(average>=81 and average<=90):
    	print("Your Grade is A");
    elif(average>=71 and average<=80):
    	print("Your Grade is B+");
    elif(average>=61 and average<=70):
    	print("Your Grade is B");
    elif(average>=51 and average<=60):
    	print("Your Grade is C+");
    elif(average>=41 and average<=50):
    	print("Your Grade is C");
    elif(average>=0 and average<=40):
    	print("Your Grade is F");
    else:
    	print("Strange Grade..!!");
     

## ---(Wed Jan  1 18:22:48 2020)---
7 + 8
> import pylab
>>> pylab.plot(range(10), 'o')
matplotlib inline
matplotlib qt
import pylab
pylab.plot(range(10), 'o')

## ---(Tue Mar 17 23:56:52 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Wed Mar 25 09:25:38 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Tue Mar 31 14:06:16 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Thu Apr 30 21:14:39 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Sat May  9 17:53:56 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Fri May 29 19:07:44 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Thu Jul  2 15:48:02 2020)---
runfile('C:/Users/Tonde Chiremba/tondeprod/Fuzzy C code.py', wdir='C:/Users/Tonde Chiremba/tondeprod')

## ---(Fri Jul  3 11:06:44 2020)---
runfile('C:/Users/Tonde Chiremba/tondeprod/fuzzyc.py', wdir='C:/Users/Tonde Chiremba/tondeprod')

## ---(Thu Jul  9 13:27:03 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Wed Jul 22 01:08:33 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Thu Jul 30 09:14:01 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Tue Aug 11 10:37:24 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Tue Aug 11 12:09:14 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')

## ---(Tue Aug 25 03:41:58 2020)---
runfile('C:/Users/Tonde Chiremba/.spyder-py3/temp.py', wdir='C:/Users/Tonde Chiremba/.spyder-py3')